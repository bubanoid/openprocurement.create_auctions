To create a distribution run:
python setup.py sdist